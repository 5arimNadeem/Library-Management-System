package com.jsp.lms.view;

import java.util.Scanner;

import com.jsp.lms.controller.Controller;
import com.jsp.lms.model.Book;
import com.jsp.lms.model.Library;

public class View {

	public static Library library = new Library();
	Book book = new Book();
	
	public static Library getLibrary() {
		return library;
	}

	public static void setLibrary(Library library) {
		View.library = library;
	}

	static Scanner myInput = new Scanner(System.in);
	static Controller controller = new Controller();

	static {

		System.out.println("--------WELCOME TO LIBRARY MANAGEMENT SYSTEM--------");

		System.out.print("Enter name of library: ");
		String libraryName = myInput.nextLine();
		library.setLibraryName(libraryName);

		System.out.print("Enter address of library: ");
		String libraryAdd = myInput.nextLine();
		library.setLibraryAddress(libraryAdd);

		System.out.print("Enter the pinCode: ");
		// int pincode = myInput.nextInt();
		library.setPincode(myInput.nextInt());
		// in this above step we can pass directly myInput.nextInt without declaring

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println("Name:"+library.getLibraryName());
//		System.out.println("Add:"+library.getLibraryAddress());
//		System.out.println("pincode :"+library.getPincode());
//		this above printing system to use the check the code

		do {

			System.out.println("Select the option to perform: ");
			System.out.println(" 1.Add Book \n 2.Remove Book \n 3.Update Book \n 4.GetBook \n 0.Exit");
			System.out.print("Enter the digit respective to desire option: ");
			Byte userInput = myInput.nextByte();
			myInput.nextLine();
			switch (userInput) {
			
			case 0:
				myInput.close();
				System.out.println("---------E X I T E D---------");
				System.exit(0);
				break;
				
			case 1:
				
				Book book = new Book();
				
				controller.addBook(book);
				
				System.out.println("Enter the BookName: ");
				book.setBookName(myInput.nextLine());
				
				System.out.println("Enter the AuthorName: ");
				book.setBookAuthor(myInput.nextLine());
				
				System.out.println("Enter the BookPrice:");
				book.setBookPrice(myInput.nextDouble());
				
				break;
				
				
			
			case 2:
				
//			    System.out.println("Enter the name of the book you want to remove: ");
//			    
//			    boolean removed = controller.removeBook(myInput.nextLine());
//			    if (removed) {
//			        System.out.println("Book removed successfully.");
//			    } else {
//			        System.out.println("Book not found in the library.");
//			    }
//			    break;
				System.out.print("Enter the book name to be remove: ");
				String bookToRemove = myInput.nextLine();
				if (controller.removeBook(bookToRemove)) {
					System.out.println("Requested book has been removed");
				} else {
					System.out.println("Book does not exit");
				}
				break;
				
			case 3:
					System.out.println("Enter the name to Update: ");
					Book bookExist = controller.getBook(myInput.nextLine());
					if (bookExist != null) {// book is exit
						Book bookToUpdate = bookExist;
						System.out.println("What to update");
						System.out.println("1.Book name	\n2.Author name \n3.Book Price");
						System.out.println("Enter digit respective to desired option:");
						
						byte UpdateChoice = myInput.nextByte();
						myInput.nextLine();
						switch (UpdateChoice) {
						
						case 1:
							System.out.print("Enter a book name to update: ");
							// String newBookName = myInput.nextLine();
							bookToUpdate.setBookName(myInput.nextLine());	
							break;
							
						case 2:
							System.out.print("Enter a author name to update: ");
							// String newAuthorName = myInput.nextLine();
							bookToUpdate.setBookAuthor(myInput.nextLine());
							break;
							
						case 3:
							System.out.println("Enter a book price to update: ");
							//double newBookPrice = myInput.nextDouble();
							bookToUpdate.setBookPrice(myInput.nextDouble());
							break;
							
							

						default:
							System.out.println("Please enter valid option. ");
							break;
						}
						if (controller.update(bookExist, bookToUpdate)) {
							System.out.println("Book updated successfully.");
							
						} else {
							System.out.println("failed to update the book. please try again");
						}
							
						}
			

				break;
			case 4:
				
				System.out.println("Enter book name you are looking for: ");
			    Book fetchBook = controller.getBook(myInput.nextLine());
			    if (fetchBook != null) {
			    	
			    	System.out.println("Books is available");
			    	System.out.println("Details");
			    	System.out.println(fetchBook);
					
				} else {   
					
					System.out.println("Book is not available");

				}

				break;

			default:
				break;
			}

		} while (true);
	}

}
